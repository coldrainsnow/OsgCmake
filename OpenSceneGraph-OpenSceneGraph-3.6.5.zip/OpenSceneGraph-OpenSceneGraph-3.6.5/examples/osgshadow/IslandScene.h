#ifndef ISLANDSCENE_H
#define ISLANDSCENE_H

// declare namespace and function to create the island scene 
namespace ModelFour { 
    osg::Node* createModel(osg::ArgumentParser& /*arguments*/); 
}

#endif
